#!/usr/bin/env node
import { readFileSync } from "node:fs";
import {
  callRemoteTool,
  clientConfig,
  parseRemoteResult,
  prepareConversionRequest,
  publishResource,
  validateJobId,
} from "./hwp2024_mcp_client_core.mjs";

const commandNames = new Set(["convert", "start", "status", "download"]);
const terminalStatuses = new Set(["succeeded", "failed", "expired"]);

function usage() {
  return [
    "Usage:",
    "  hwp2024-mcp-convert convert --env-file .env.local --input INPUT.hwp --target pdf --engine 2024 --output-dir OUT_DIR",
    "  hwp2024-mcp-convert start --env-file .env.local --input INPUT.hwp --target pdf --engine 2024",
    "  hwp2024-mcp-convert status --env-file .env.local --job-id JOB_ID",
    "  hwp2024-mcp-convert download --env-file .env.local --job-id JOB_ID --output-dir OUT_DIR",
    "",
    "Commands:",
    "  convert                    Synchronous upload, remote conversion, verification, and local save (default).",
    "  start                      Upload a local document and queue an asynchronous remote conversion.",
    "  status                     Query an asynchronous remote job state.",
    "  download                   Download, verify, and locally save a succeeded remote result.",
    "",
    "Options:",
    "  --env-file PATH           File containing HWP2024_MCP_SERVER_URL and HWP2024_MCP_AUTH_TOKEN.",
    "  --server-url URL          Remote Streamable HTTP MCP endpoint.",
    "  --auth-token TOKEN        Bearer token; prefer the private environment file.",
    "  --input PATH              Client-local .hwp or .hwpx path for convert/start.",
    "  --target pdf|hwp|hwpx     Conversion target for convert/start; defaults to pdf.",
    "  --engine 2020|2024        Windows Hancom engine; defaults to 2024.",
    "  --password-file PATH      Read an optional document password from a private single-line file.",
    "  --job-id UUID             Job ID returned by start for status/download.",
    "  --output-dir DIR          Client-local result directory for convert/download.",
    "  --output-filename NAME    Optional target filename without a directory component.",
    "  --timeout-seconds N       Remote conversion timeout, range 10..1800; defaults to 600.",
  ].join("\n");
}

function parseArgs(argv) {
  const values = [...argv];
  const options = { command: "convert", target: "pdf", engine: "2024", timeoutSeconds: 600 };
  if (commandNames.has(values[0])) options.command = values.shift();
  for (let index = 0; index < values.length; index += 1) {
    const arg = values[index];
    const next = () => {
      index += 1;
      if (index >= values.length) throw new Error(`missing value for ${arg}`);
      return values[index];
    };
    if (arg === "--help" || arg === "-h") options.help = true;
    else if (arg === "--env-file") options.envFile = next();
    else if (arg === "--server-url") options.serverUrl = next();
    else if (arg === "--auth-token") options.authToken = next();
    else if (arg === "--input") options.input = next();
    else if (arg === "--target") options.target = next();
    else if (arg === "--engine") options.engine = next();
    else if (arg === "--password-file") options.passwordFile = next();
    else if (arg === "--job-id") options.jobId = next();
    else if (arg === "--output-dir") options.outputDir = next();
    else if (arg === "--output-filename") options.outputFilename = next();
    else if (arg === "--timeout-seconds") options.timeoutSeconds = Number.parseInt(next(), 10);
    else throw new Error(`unknown argument: ${arg}`);
  }
  return options;
}

function readDocumentPassword(filePath) {
  if (!filePath) return undefined;
  const raw = readFileSync(filePath, "utf8");
  const password = raw.endsWith("\r\n") ? raw.slice(0, -2) : raw.endsWith("\n") ? raw.slice(0, -1) : raw;
  if (!password || /[\r\n]/.test(password)) {
    throw new Error("--password-file must contain exactly one non-empty password line");
  }
  return password;
}

function request(options) {
  if (!options.input) throw new Error("--input is required for convert/start");
  return prepareConversionRequest({
    input_path: options.input,
    target: options.target,
    engine: options.engine,
    output_filename: options.outputFilename,
    timeout_seconds: options.timeoutSeconds,
    password: readDocumentPassword(options.passwordFile),
  });
}

async function convert(config, options) {
  if (!options.outputDir) throw new Error("--output-dir is required for convert");
  const prepared = request(options);
  const remote = await callRemoteTool(config, "convert_document", prepared.remoteArguments, (prepared.timeoutSeconds + 120) * 1000);
  const server = parseRemoteResult(remote);
  const saved = await publishResource(remote, server, options.outputDir, options.outputFilename);
  return { status: "success", input_path: prepared.inputPath, output_path: saved.outputPath, target: prepared.target, size: saved.size, sha256: saved.sha256, server };
}

async function start(config, options) {
  const prepared = request(options);
  return parseRemoteResult(await callRemoteTool(config, "start_conversion", prepared.remoteArguments, 120_000));
}

async function status(config, options) {
  const jobId = validateJobId(options.jobId);
  const result = parseRemoteResult(await callRemoteTool(config, "get_conversion_status", { job_id: jobId }, 120_000));
  return { ...result, terminal: terminalStatuses.has(result.status) };
}

async function download(config, options) {
  const jobId = validateJobId(options.jobId);
  if (!options.outputDir) throw new Error("--output-dir is required for download");
  const remote = await callRemoteTool(config, "get_conversion_result", { job_id: jobId }, 120_000);
  const server = parseRemoteResult(remote);
  const saved = await publishResource(remote, server, options.outputDir, options.outputFilename);
  return { status: "success", job_id: jobId, output_path: saved.outputPath, output_filename: saved.outputFilename, size: saved.size, sha256: saved.sha256, server };
}

async function main() {
  const options = parseArgs(process.argv.slice(2));
  if (options.help) {
    console.log(usage());
    return;
  }
  const config = clientConfig(options);
  const handlers = { convert, start, status, download };
  console.log(JSON.stringify(await handlers[options.command](config, options), null, 2));
}

main().catch((error) => {
  process.stderr.write(`${error instanceof Error ? error.message : String(error)}\n`);
  process.exitCode = 1;
});
